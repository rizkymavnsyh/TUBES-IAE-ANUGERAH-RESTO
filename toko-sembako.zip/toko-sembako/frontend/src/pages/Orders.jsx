export default function Orders() {
  return (
    <div style={{ padding: 20 }}>
      <h1>Orders</h1>

      <ul>
        <li>
          Order #1 - Total: 24.000 - <b>CONFIRMED</b>
        </li>
        <li>
          Order #2 - Total: 30.000 - <b>CANCELLED</b>
        </li>
      </ul>
    </div>
  );
}
