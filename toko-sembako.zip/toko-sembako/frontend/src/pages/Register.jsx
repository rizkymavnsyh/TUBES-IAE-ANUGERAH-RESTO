export default function Register() {
  return (
    <div style={{ padding: 20 }}>
      <h1>Register</h1>

      <input placeholder="Email" />
      <br />
      <input placeholder="Password" type="password" />
      <br />
      <button>Register</button>
    </div>
  );
}
