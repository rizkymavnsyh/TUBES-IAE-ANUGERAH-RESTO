export default function Login() {
  return (
    <div style={{ padding: 20 }}>
      <h1>Login</h1>

      <input placeholder="Email" />
      <br />
      <input placeholder="Password" type="password" />
      <br />
      <button>Login</button>
    </div>
  );
}
