export default function Inventory() {
  return (
    <div style={{ padding: 20 }}>
      <h1>Inventory</h1>

      <ul>
        <li>Produk ID 1 - Stok: 45</li>
        <li>Produk ID 2 - Stok: 20</li>
      </ul>
    </div>
  );
}
