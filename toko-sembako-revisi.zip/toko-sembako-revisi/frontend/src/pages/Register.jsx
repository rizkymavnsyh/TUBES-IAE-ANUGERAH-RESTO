function Register() {
  return (
    <div style={{ paddingTop: "80px", paddingLeft: "24px" }}>
      <h1>Register</h1>
      <p>Halaman Register Toko Sembako</p>
    </div>
  );
}

export default Register;
