function Login() {
  return (
    <div style={{ paddingTop: "80px", paddingLeft: "24px" }}>
      <h1>Login</h1>
      <p>Halaman Login Toko Sembako</p>
    </div>
  );
}

export default Login;
