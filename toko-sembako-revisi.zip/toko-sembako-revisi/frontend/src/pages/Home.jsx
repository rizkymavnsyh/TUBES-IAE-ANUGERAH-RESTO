export default function Home() {
  return (
    <div style={{ padding: 20 }}>
      <h1>Dashboard</h1>
      <p>Selamat datang di sistem Toko Sembako</p>
    </div>
  );
}
